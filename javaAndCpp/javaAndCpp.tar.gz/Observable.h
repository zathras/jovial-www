//
//		Observable.h
//
//  A simple-minded observable class in C++.  cf. Observer.h.
//
// This is a *very* bad implementation, but, given the lack of a standard
// container class library in C++, it's nontrivial to do better.


#if !defined(Observable_h)
#define Observable_h

#include "Observer.h"

class Observable {


    public:

	Observable();
	~Observable();

	void addObserver(Observer* o);
	void deleteObserver(Observer* o);
	void notifyObservers();

    private:

	enum { capacity_ = 20 };
	Observer* observers_[capacity_];
	int numObservers_;
};

#endif
