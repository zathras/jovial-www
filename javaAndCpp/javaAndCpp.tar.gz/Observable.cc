//
//  Observable.cc
//
//  cf. Observable.h


#include "Observable.h"
#include <assert.h>

Observable::Observable()
    : numObservers_(0)

{
}

Observable::~Observable()

{
}

void Observable::addObserver(Observer* o)

{
    assert(numObservers_ < capacity_);
    if (numObservers_ >= capacity_)
	return;
    assert(o != (void *) 0);
    observers_[numObservers_++] = o;
}

void Observable::deleteObserver(Observer* o)

{
    for (int i = 0; i < numObservers_; i++)  {
	if (observers_[i] == o)  {
	    numObservers_--;
	    for (int j = i; j < numObservers_; j++)
		observers_[j] = observers_[j+1];
	    return;
	}
    }
    assert(0);		// o should have been in the list
}

void Observable::notifyObservers()

{
    for (int i = 0; i < numObservers_; i++)
	observers_[i]->update();
}

