//
//  NumberList.h
//
//  This silly class implements a (crude) list of numbers.  It is an
//  Observable object.


#if !defined(NumberList_h)
#define NumberList_h

#include "Observable.h"

class NumberList : public Observable {

    public:

	NumberList();
	~NumberList();

	void addNumber(int n);		// add n to the list
	int size()		
	    { return numNumbers_; }
	int getNumber(int i);		// get the ith number
    
    private:

	enum { capacity_ = 100 };
	int numbers_[capacity_];
	int numNumbers_;

};

#endif
