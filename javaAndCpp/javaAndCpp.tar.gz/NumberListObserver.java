/**
    @author Bill Foote, http://www.jovial.com/~billf/
    @version 1.0

    <p>
    This class is a simple observer for a NubmerListProxy.  When the number
    list changes, this observer dumps a line to stdout.
    @see NumberListProxy

**/

import java.util.*;

class NumberListObserver implements Observer  {
    NumberListObserver(NumberListProxy subject)  {
	subject_ = subject;
	subject.addObserver(this);
    }

    /**
     * Called when the subject changed
     * @param o not used
     * @param arg not used
    **/
    public void update(Observable o, Object arg)  {
	synchronized (subject_)  {    // Don't want size() to change under us!
	    int sz = subject_.size();
	    System.out.print("    The list now has:  ");
	    for (int i = 0; i < sz; i++)  {
		if (i > 0)
		    System.out.print(", ");
		System.out.print(subject_.getNumber(i));
	    }
	}
	System.out.println("");
    }

    private NumberListProxy subject_;		// Thing being observed
}
