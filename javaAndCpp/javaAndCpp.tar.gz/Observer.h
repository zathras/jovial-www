//
//		Observer.h
//
//  A simple-minded observer interface in C++.  cf. Observable.h


#if !defined(Observer_h)
#define Observer_h

class Observer {

    public:

	virtual void update() = 0;

};

#endif
