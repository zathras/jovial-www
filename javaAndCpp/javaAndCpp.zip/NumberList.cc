//
//  NumberList.cc
//
//  cf. NumberList.h


#include "NumberList.h"
#include <assert.h>
#include <stdio.h>

NumberList::NumberList()
    : numNumbers_(0)
{
}

NumberList::~NumberList()

{
}


void NumberList::addNumber(int n)

{
    assert(numNumbers_ < capacity_);
    if (numNumbers_ < capacity_) {
	numbers_[numNumbers_++] = n;
	notifyObservers();
    }
}


int NumberList::getNumber(int i)

{
    assert(i >= 0 && i < numNumbers_);
    return numbers_[i];
}
