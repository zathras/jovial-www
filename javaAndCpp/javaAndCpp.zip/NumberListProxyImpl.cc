//
//	NumberListProxyImpl.cc
//
//
//  This file contains the C++ code that implements the stubs generated
//  by "javah -stubs NumberListProxy".  cf. NumberListProxy.c.

#include <StubPreamble.h>
#include "NumberListProxy.h"
#include "NumberList.h"
#include "JavaObservableProxy.h"

void NumberListProxy_initCppSide(struct HNumberListProxy *javaObj)

{
    NumberList* list = new NumberList();
    struct HObservable* observable = (struct HObservable*) javaObj;
    JavaObservableProxy* proxy = new JavaObservableProxy(observable, list);
    unhand(javaObj)->numberListPtr_ = (long) list;
    unhand(javaObj)->javaProxyPtr_ = (long) proxy;
}

void NumberListProxy_detach(struct HNumberListProxy* javaObj)

{
    NumberList* list = (NumberList*) unhand(javaObj)->numberListPtr_;
    JavaObservableProxy* proxy 
	= (JavaObservableProxy*) unhand(javaObj)->javaProxyPtr_;
    delete proxy;
    delete list;
}

void NumberListProxy_addNumber(struct HNumberListProxy* javaObj,long v)

{
    NumberList* list = (NumberList*) unhand(javaObj)->numberListPtr_;
    list->addNumber(v);
}

long NumberListProxy_size(struct HNumberListProxy* javaObj)

{
    NumberList* list = (NumberList*) unhand(javaObj)->numberListPtr_;
    return list->size();
}

long NumberListProxy_getNumber(struct HNumberListProxy* javaObj, long i)

{
    NumberList* list = (NumberList*) unhand(javaObj)->numberListPtr_;
    return list->getNumber(i);
}

