//
//  JavaObservableProxy.cc
//
//  cf. JavaObservableProxy.h


#include "JavaObservableProxy.h"
#include <StubPreamble.h>
    // N.B.  <interpreter.h>, included, by StubPreamble.h, has a bug.  They
    // forgot these lines at the beginning and end:
    // #ifdef __cplusplus
    // extern "C" {
    // #endif
    //    ...  and ...
    // #ifdef __cplusplus
    // }
    // #endif

#include <assert.h>

static ClassClass* javaObjectHolder()

    // Give a pointer to the class descriptor for JavaObjectHolder

{
    static ClassClass* result = 0;
    if (result == 0)  {
	result = FindClass(0, "JavaObjectHolder", TRUE);
	assert(result != 0);
    }
    return result;
}

JavaObservableProxy::JavaObservableProxy(
	struct HObservable* javaObj, 
	Observable* obs)

{
    javaObjectId_ = execute_java_static_method(
			0, javaObjectHolder(), "addObject", 
			"(Ljava/lang/Object;)I",
			javaObj);
    observedOne_ = obs;
    observedOne_->addObserver(this);
}

JavaObservableProxy::~JavaObservableProxy()

{
    observedOne_->deleteObserver(this);
    execute_java_static_method(
	0, javaObjectHolder(), "removeObject", "(I)V", javaObjectId_);
    javaObjectId_ = -1;
}

void JavaObservableProxy::update()

{
    HObject* javaObj = (HObject*)
	execute_java_static_method(
	    0, javaObjectHolder(), "getObject", "(I)Ljava/lang/Object;", 
	    javaObjectId_);

	// If an exception occurred, get back to the Java runtime, because
	// invoking another method would clear the exception flag.
    if (exceptionOccurred(EE()))
	return;

    execute_java_dynamic_method(0, javaObj, "setChanged", "()V");

    if (exceptionOccurred(EE()))
	return;

    execute_java_dynamic_method(0, javaObj, "notifyObservers", "()V");
}

