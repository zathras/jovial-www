//
//  JavaObservableProxy.h
//
//  A JavaObservableProxy is the C++ side of a Java object that is a
//  proxy for a C++ observable.
//
//  Whew.  In simpler English:  Suppose you have a C++ object that
//  implements an Observable protocol.  Further suppose that you want
//  to make a Java proxy to that object.  Calling from the Java object
//  to the C++ object is simple, but what happens when the C++ object
//  changes?  How does the C++ object notify its Java proxy that it has
//  changed, when the C++ object doesn't know about the existance of Java?
//
//  The answer is JavaObservableProxy.  The Java proxy is expected to
//  be a subclass of java.util.Observable.  Further, the Java proxy
//  should hold onto an instance of JavaObservableProxy.  When the C++
//  object sends out an update message, JavaObservableProxy will receive
//  it.  It will then call setChanged() and notifyObservers() on the Java
//  object.  In this way, objects watching the Java proxy will be notified
//  whenever the C++ object sends out a notification.
//
//  The Java object *must* delete the proxy when it is done with it.

#if !defined(JavaObservableProxy_h)
#define JavaObservableProxy_h

#include "Observer.h"
#include "Observable.h"

class JavaObservableProxy : public Observer {

    public:

	JavaObservableProxy(struct HObservable* javaObj, Observable* obs);
	~JavaObservableProxy();

	void update();

    private:

	int javaObjectId_;
	Observable* observedOne_;
};

#endif
