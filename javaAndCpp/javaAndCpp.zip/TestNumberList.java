/**
    @author Bill Foote, http://www.jovial.com/~billf/
    @version 1.0

    <p>
    This silly little program demonstrates NumberListProxy by creating
    one, creating a NumberListObserver to observe it, then modifying
    the numberList.
    @see NumberListProxy
    @see NumberListObserver
**/

import java.util.*;

class TestNumberList {

    public static void main(String args[]) {
	NumberListProxy model = new NumberListProxy();
	NumberListObserver obs = new NumberListObserver(model);

	System.out.println("Adding 3 to the list...");
	model.addNumber(3);
	System.out.println("Adding 42 to the list...");
	model.addNumber(42);
	System.out.println("Adding 666 to the list...");
	model.addNumber(666);
	System.out.println("Adding 7 to the list...");
	model.addNumber(7);

	model.deleteObserver(obs);
	model.detach();
    }
}
