
/**
    @author Bill Foote, http://www.jovial.com/~billf/
    @version 1.0

    <p>
    This singleton class implements a workaround to the problem of
    storing references to Java objects within C++ objects.  While
    we're waiting for something built into the environment
    (cf. http://home.netscape.com/eng/jri/), we need to add
    a level of indirection, to make sure that the Java objects 
    aren't garbage collected, and to make the C++ code still
    work if a Java object is moved by the collector.
    <p>
    To do that, we store "references" to Java objects as integers.
    The integer is a "handle" given to the C++ object by the
    JavaObjectHolder singleton.  The C++ code can convert its
    handle into a "struct HObject*" by calling into the JavaObjectHolder
    singleton.
**/

import java.util.*;

class JavaObjectHolder {


    /**
     * Add a Java object, and return its (new) handle.  If the same object
     * is added multiple times, it will be assigned multiple handles.
     * @see JavaObjectHolder#removeObject
     * @param o The object to add.  May not be null.
     * @return The handle to the object.  Must be released with removeObject()
     * @throws NullPointerException if o is null
    **/

    public static int addObject(Object o)  
	throws NullPointerException
    {
	    // We must synchronize on theObjects_ in case another thread tries
	    // to do this.  We can't just make the method synchronized, because
	    // static synchronized methods don't mean anything (at least not
	    // in JDK 1.0.2!)
	synchronized (theObjects_) {
	    if (o == null)
		throw new NullPointerException();
	    int sz = theObjects_.size();
	    while (nextSlotToTry_ < sz) {
		if (theObjects_.elementAt(nextSlotToTry_) == null)  {
		    int handle = nextSlotToTry_;
		    emptySlots_--;
		    theObjects_.setElementAt(o, handle);
		    nextSlotToTry_++;
		    return handle;
		}
		nextSlotToTry_++;
		if (nextSlotToTry_ >= sz)
		    considerRecyclingSlots();
	    }
	    int handle = nextSlotToTry_;
	    nextSlotToTry_++;
	    theObjects_.addElement(o);
	    return handle;
	}
    }

    /**
     * Removes a java object from the holder.
     * @see JavaObjectHolder#addObject
     * @param handle A handle to the object to be removed.  Once an object
     *               is removed, the value of its handle might be reused.
     * @throws IndexOutOfBoundsException if handle is not valid
    **/
    public static void removeObject(int handle) 
	throws IndexOutOfBoundsException
    {
	synchronized (theObjects_)  {
	    if (theObjects_.elementAt(handle) == null)
		throw new IndexOutOfBoundsException();
	    theObjects_.setElementAt(null, handle);
	    considerRecyclingSlots();
	}
    }

    /**
     * Get an object, given its handle.
     * @param handle A handle to the desired object
     * @return The object.  Will never be null.
     * @throws IndexOutOfBoundsException if handle is not valid
    **/
    public static Object getObject(int handle)
	throws IndexOutOfBoundsException
    {
	Object o = theObjects_.elementAt(handle);
	if (o == null)
	    throw new IndexOutOfBoundsException();	// handle is not valid
	return o;
    }

	// Figure out if it makes sense to recycle slots now.
    private static void considerRecyclingSlots()  {
	int s = theObjects_.size();
	if (nextSlotToTry_ >= s && emptySlots_ > s/2)
	    nextSlotToTry_ = 0;		// Recycle them
    }

    private static Vector theObjects_;		
	// Internal storage for objects.  An entry is set null when it's
	// removed.

    private static int    emptySlots_;  	
	// How many entries in theObjects_ are null?  Once this gets
	// over half the size of theObjects_, we'll start to re-use
	// empty slots.

    private static int 	nextSlotToTry_;
	// From time to time, we go through theObjects_, re-using entries.
	// nextSlotToTry_ is set to the next index we'll check in theObjects_
	// when addObject() is called next.
    
    static {
	theObjects_ = new Vector();
	emptySlots_ = 0;
	nextSlotToTry_ = 0;
    }
}
