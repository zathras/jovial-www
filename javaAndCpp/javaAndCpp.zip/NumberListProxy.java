/**
    @author Bill Foote, http://www.jovial.com/~billf/
    @version 1.0

    <p>
    This class acts as a proxy for the C++ class NumberList.
    @see NumberList.h
    <p>
    To generate the C "glue" code, to this:
    <ul>
    <li>javah NumberListProxy</li>
    <li>javah -stubs NumberListProxy</li>
    <li>Implement the extern functions in NumberListProxy somewhere</li>
    </ul>

**/

import java.util.*;

class NumberListProxy extends Observable {

    static {
	System.loadLibrary("NumberList");
    }

    NumberListProxy()  {
	initCppSide();
    }

    /**
     * Add a number to the end of the list
     * @param n The number to add
    **/
    public native void addNumber(int n);

    /**
     * @return the size of the list
    **/
    public native int size();

    /**
     * Get element i from the list
     * @param i Index of element, 0..size()-1
     * @return The value
    **/
    public native int getNumber(int i);


    /**
     * Detach ourselves from the C++ NumberList.  In other words, delete the
     * C++ object.  Once detach() is called, other methods must <b>never</b>
     * be called.
     * <p>
     * We can't just override finalize(), because our JavaObservableProxy
     * maintains a reference to us, so we can never be garbage-collected.
     */
    public native void detach();

    /**
     * Initialize the C++ side, i.e. create the C++ objects.
     */
    private native void initCppSide();

    private int numberListPtr_;		// NumberList*
    private int javaProxyPtr_;		// JavaObservableProxy*
}
