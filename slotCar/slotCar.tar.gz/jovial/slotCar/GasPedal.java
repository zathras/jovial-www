/*
	File:  GasPedal.java

	Date		Author		Changes
	09/13/96	Bill Foote	Created

*/

/**
 *  Interface for objects representing a Gas Pedal for a car.
 *
 * @version 	1.0, September 13 1996
 * @author 	Bill Foote
 */

package jovial.slotCar;

import java.util.*;

public interface GasPedal {

    /**
     * Tell us how far the throttle is down
     * return Number in the range 0..1, where 1 is full-throttle
    **/
    public double getThrottle();

}
