/*
	File:  RaceView.java

	Date		Author		Changes
	9/12/96		Bill Foote	Created
*/

package jovial.slotCar;

import java.util.*;
import java.awt.*;
import jovial.slotCar.animator.Animator;
import jovial.slotCar.animator.Animatee;
import jovial.slotCar.track.Track;
import jovial.slotCar.track.TrackPosition;


/**
 *  A class representing a view of a slot-car race.  This class creates 
 *  a slot-car race and sets it in motion..
 *
 * @see		Animatee
 * @see		Animator
 * @version	1.0 12 Sep 1996
 * @author	Bill Foote
**/


public class RaceView extends Animatee {

    /**
     * Initialize a new RaceView
     * @param animator He who animates us.  We provide him with drawables.
    **/
    public RaceView(Animator animator)  {
	animator.init(this);
	Color darkGreen = new Color(0, 128, 0);
	if (darkGreen != null)  {
	    animator.setBackground(darkGreen);
	}
	Track t = Track.createFigureEightTrack(animator);
	Color eraseColor = t.color();
	
	cars_ = new Car[2];
	TrackPosition pos = new TrackPosition(0, t.firstSegment());
	cars_[0] = new Car(pos, Color.red, eraseColor,
			   new RandomGasPedal());
	pos = new TrackPosition(1, t.firstSegment());
	cars_[1] = new Car(pos, Color.yellow, eraseColor,
			   new RandomGasPedal());
	animator.addDrawable(cars_[0]);
	animator.addDrawable(cars_[1]);
    }
    
    /**
     * Move the race along in time
     * @param deltaT Time since last call, in milliseconds
    **/
    public void move(long deltaT)  {
	for (int i = 0; i < cars_.length; i++)
	    cars_[i].move(deltaT);
    }
    
    /**
     * Give the size our view will want to be
     * @return Dimension The size, in pixels
    **/
    public Dimension preferredSize() {
	return new Dimension(530, 300);
    }

    Car cars_[];
}
