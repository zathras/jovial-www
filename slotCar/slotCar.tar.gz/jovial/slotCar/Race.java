/*
	File:  Race.java

	Date		Author		Changes
	9/11/96		Bill Foote	Created
*/

package jovial.slotCar;

import java.util.*;
import java.awt.*;
import jovial.slotCar.animator.Animator;


/**
 *  A main class to start up and run a slot-car rase.
**/


public class Race extends Frame {

    /**
     * Handle an event from one of our widgets
     * @param evt The event
     * @return true if it was handled
    **/
    public boolean handleEvent(Event evt)  {
        if (evt.id == Event.WINDOW_DESTROY) {
            System.exit(0);
	}
	return super.handleEvent(evt);
    }


    /**
     * Run the program
    **/
    public static void main(String argv[])  {
	Race r = new Race();
	GridBagLayout layout = new GridBagLayout();
	r.setLayout(layout);

	Animator a = new Animator();
	RaceView rv = new RaceView(a);
	{

	    GridBagConstraints c = new GridBagConstraints();
	    c.fill = GridBagConstraints.BOTH;
	    c.weightx = 1;
	    c.weighty = 1;
	    layout.setConstraints(a, c);
	    r.add(a);
	}

	r.pack();
	r.show();

	new Thread(a).start();
    }
}
