/*
	File:  StraightTrackSegment.java

	Date		Author		Changes
	09/12/96	Bill Foote	Created

*/

package jovial.slotCar.track;

import java.util.*;
import java.awt.*;
import java.awt.Point;

/**
 *
 *  Represents a straight piece of track.
 *  <p>
 *  See also FigureEightTrack.gif for a description of the meaning
 *  of the variables.
 *
 *
 * @version 	1.0, September 12 1996
 * @author 	Bill Foote
 */

class StraightTrackSegment extends TrackSegment {

    /**
     * Initialize a new straight track segment
     * @param c The color to draw this segment
     * @param x0 "Origin" x point at one corner (see diagram)
     * @param y0 "Origin" y point at one corner (see diagram)
     * @param l length of segment
     * @param w width of segment
     * @param theta Angle segment is off from horizontal, pointing to right
     * @param next Next track segment we connect to
    **/
    protected StraightTrackSegment(Color c,
				   int x0, int y0, int l, int w, double theta, 
			           TrackSegment next)
    {
	super(next, c);
	length_ = l;
	theta_ = theta;
	border_ = new Polygon[2];
	
	dx_ = Math.cos(theta);
	dy_ = -Math.sin(theta);
	x0Inside_ = x0 + (int) ((w / 3.0) * (-Math.sin(theta)));
	y0Inside_ = y0 + (int) ((w / 3.0) * (-Math.cos(theta)));
	x0Outside_ = x0 + (int) ((w * 2.0 / 3.0) * (-Math.sin(theta)));
	y0Outside_ = y0 + (int) ((w * 2.0 / 3.0) * (-Math.cos(theta)));

	    // The y's have subtractions because Java's coordinate
	    // system has increasing y pointing down, but their
	    // angular system (cf. Graphics.drawArc()) has increasing
	    // angles spinning counter-clockwise.
	{
	    int[] xs = new int[4];
	    int[] ys = new int[4];
	    xs[0] = x0;
	    ys[0] = y0;
	    xs[1] = (int) (x0 + w * Math.cos(theta + Math.PI/2.0));
	    ys[1] = (int) (y0 - w * Math.sin(theta + Math.PI/2.0));
	    xs[2] = (int) (xs[1] + l * Math.cos(theta));
	    ys[2] = (int) (ys[1] - l * Math.sin(theta));
	    xs[3] = (int) (x0 + l * Math.cos(theta));
	    ys[3] = (int) (y0 - l * Math.sin(theta));
	    trackPolygon_ = new Polygon(xs, ys, 4);
	}
	{
	    int[] xs = new int[4];
	    int[] ys = new int[4];
	    xs[0] = x0;
	    ys[0] = y0;
	    xs[1] = (int) (x0 - 4 * Math.cos(theta + Math.PI/2.0));
	    ys[1] = (int) (y0 + 4 * Math.sin(theta + Math.PI/2.0));
	    xs[2] = (int) (xs[1] + l * Math.cos(theta));
	    ys[2] = (int) (ys[1] - l * Math.sin(theta));
	    xs[3] = (int) (x0 + l * Math.cos(theta));
	    ys[3] = (int) (y0 - l * Math.sin(theta));
	    border_[0] = new Polygon(xs, ys, 4);
	}
	{
	    int[] xs = new int[4];
	    int[] ys = new int[4];
	    xs[0] = (int) (x0 + w * Math.cos(theta + Math.PI/2.0));
	    ys[0] = (int) (y0 - w * Math.sin(theta + Math.PI/2.0));
	    xs[1] = (int) (xs[0] + 4 * Math.cos(theta + Math.PI/2.0));
	    ys[1] = (int) (ys[0] - 4 * Math.sin(theta + Math.PI/2.0));
	    xs[2] = (int) (xs[1] + l * Math.cos(theta));
	    ys[2] = (int) (ys[1] - l * Math.sin(theta));
	    xs[3] = (int) (xs[0] + l * Math.cos(theta));
	    ys[3] = (int) (ys[0] - l * Math.sin(theta));
	    border_[1] = new Polygon(xs, ys, 4);
	}
    }

    /**
     * Display the track segment
     * @param g Destination for drawing
    **/
    public void paint(Graphics g)  {
	g.setColor(color());
	g.fillPolygon(trackPolygon_);
	g.setColor(Color.white);
	g.fillPolygon(border_[0]);
	g.fillPolygon(border_[1]);
    }
    
    /**
     * Move a position along the track, possibly progressing to next
     * segment.  Should only be called from TrackPosition.
     * @overrides TrackSegment#movePositionBy
     * @param pos The position to move
     * @param d The distance to move it (in pixels)
    **/
    protected void movePositionBy(TrackPosition pos, double d) {
	double newDist = d + pos.distance();
	if (newDist <= length_)  {
	    pos.setDistance(newDist);
	    pos.setOrientation(theta_);
	    int x, y;
	    if (firstSlotIsNearOrigin() ^ (pos.slot() == 1))  { // Inside
		x = (int) (x0Inside_ + newDist * dx_);
		y = (int) (y0Inside_ + newDist * dy_);
	    } else {
		x = (int) (x0Outside_ + newDist * dx_);
		y = (int) (y0Outside_ + newDist * dy_);
	    }
	    Point p = new Point(x, y);
	    pos.setPosition(p);
	} else {
	    newDist -= length_;
	    pos.setCurrSegment(next());
	    pos.setDistance(0);
	    next().movePositionBy(pos, newDist);
	}
    }


    private Polygon trackPolygon_;
    private Polygon border_[];
    private int length_;
    private double theta_;
    double x0Inside_;		// x/y position of start of inside slot
    double y0Inside_;
    double x0Outside_;		// x/y position of start of outside slot
    double y0Outside_;
    double dx_;			// dx and dy give the slope of a slot
    double dy_;
}
