/*
	File:  Car.java

	Date		Author		Changes
	09/13/96	Bill Foote	Created

*/

package jovial.slotCar;

import java.util.*;
import java.awt.*;
import jovial.slotCar.animator.Drawable;
import jovial.slotCar.track.TrackPosition;

/**
 * <P>
 * Represents a slot car.
 * <P>
 * See also Car.gif for a description of the meaning
 * of the variables.
 * <p>
 * <img src="Car.gif">
 * <p>
 *
 *
 * @see		TrackPosition
 * @see		RaceView
 * @version 	1.0, September 13 1996
 * @author 	Bill Foote
 */

public class Car extends Drawable {

    /**
     * Create a new car
     * @param pos Our initial positio
     * @param drawColor This car's color
     * @param eraseColor Color of what's under car, for erasing
     * @param gasPedal The gas pedal we should use
    **/
    public Car(TrackPosition pos, Color drawColor, Color eraseColor,
	       GasPedal gasPedal)
    {
	pos_ = pos;
	drawColor_ = drawColor;
	eraseColor_ = eraseColor;
	gasPedal_ = gasPedal;
	int[] xs = new int[4];
	int[] ys = new int[4];
	poly_ = new Polygon(xs, ys, 4);
    }
    
    /**
     * Paint this car
     * @param g Destination for drawing
    **/
    public void paint(Graphics g) {
	g.setColor(drawColor_);
	drawCar(g);
    }
    
    /**
     * Erase this Car
     * @param g The graphics on which erasing is to occur
    **/
    public void erase(Graphics g) {
	g.setColor(eraseColor_);
	drawCar(g);
    }
        
    /**
     * @return true iff this drawable might move around the screen
    **/
    public boolean canMove() {
	return true;
    }
    
    /**
     * @return the height of this drawable.  Higher drawables will be drawn
     *	       first.
    **/
    public int height() {
	return pos_.height() + 3;
    }
    
    /**
     * Move the car ahead in time
     * @param deltaT Amount of time to move
    **/
    public void move(long deltaT)  {
	pos_.moveBy(gasPedal_.getThrottle() * (deltaT / 8.00));
    }

    // Draw the car in the current color on g.
    private void drawCar(Graphics g) {
	Point p = pos_.position();
	double phi = pos_.orientation();
	poly_.xpoints[0] = (int) (p.x + df_ * Math.cos(phi + thetaF_));
	poly_.ypoints[0] = (int) (p.y - df_ * Math.sin(phi + thetaF_));
	poly_.xpoints[1] = (int) (p.x + db_ * Math.cos(Math.PI + phi - thetaB_));
	poly_.ypoints[1] = (int) (p.y - db_ * Math.sin(Math.PI + phi - thetaB_));
	poly_.xpoints[2] = (int) (p.x + db_ * Math.cos(Math.PI + phi + thetaB_));
	poly_.ypoints[2] = (int) (p.y - db_ * Math.sin(Math.PI + phi + thetaB_));
	poly_.xpoints[3] = (int) (p.x + df_ * Math.cos(phi - thetaF_));
	poly_.ypoints[3] = (int) (p.y - df_ * Math.sin(phi - thetaF_));
	g.fillPolygon(poly_);
    }
    
    private TrackPosition pos_;
    private Color drawColor_;
    private Color eraseColor_;
    private Polygon poly_;
    private GasPedal gasPedal_;
    
    private static final double thetaF_ = Math.PI / 16.0;
    private static final double df_ = 8.0;
    private static final double thetaB_ = Math.PI / 4.0;
    private static final double db_ = 4.0 * Math.sqrt(2.0);
}
