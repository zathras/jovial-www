/*
	File:  Animator.java

	Date		Author		Changes
	9/11/96		Bill Foote	Created
*/

package jovial.slotCar.animator;

import java.util.*;
import java.awt.*;

/**
 *  A class representing an animated Canvas.  This canvas constantly
 *  moves its components forward in time, and asks them to re-draw
 *  themselves.  It uses double-buffering to prevent flashiness.
 *  <p>
 *  This class interacts with two others:  Animatee, and Drawable.  At
 *  start-up, it is configured with a number of drawables.  It then enters
 *  a loop, where it tells the Animatee to move (by a time interval), then
 *  it draws its Drawables (in increasing order of height, so that overlapping
 *  works).
 *  <p>
 *  As a concession to efficiency, we adopted the convention that Drawables
 *  with a height <= 0 won't be re-drawn in each successive frame.  Think
 *  of them as a "background" image.  In addition, Drawables that canMove()
 *  are asked to erase() themselves after each frame.  If these restrictions
 *  are too much, you can always make sure all your Drawables have a height
 *  >= 1, and maybe make your lowest Drawable be a rectangle that erases
 *  the entire screen.
 *  <p>
 *  Use:
 *  <pre>
 *	Animator a = new Animator(myAnimatee);
 *	new Thread(a).start();
 *  </pre>
 *
 * @see	Animatee
 * @see	Drawable
 * @version	1.0 11 Sep 1996
 * @author	Bill Foote
**/

public class Animator extends Canvas implements Runnable {

    /**
     * Initialize a new animator.  Be sure to call init() with the
     * animatee later!
    **/
    public Animator()  {
	animatee_ = null;
	drawables_ = new Vector();
    }
    
    /**
     * Initialize us with an animatee.  Should be called from the
     * Animatee's constructor.
     * @param a What we are to animate
    **/
    public void init(Animatee a) {
	animatee_ = a;
    }
    
    /**
     * Paint this canvas
    **/
    public void paint (Graphics g)  {
    }

    /**
     * Give our preferred size
     * @return the size
    **/
    public Dimension preferredSize()  {
	return animatee_.preferredSize();
    }
    
    /**
     * Add to the list of things that we draw
     * @param d The new drawable
    **/
    public void addDrawable(Drawable d) {
	drawables_.addElement(d);
    }

    /**
     * Cause this animator to start running.
    **/
    public void run () {
	long currentTime = System.currentTimeMillis();
	Image image = createImage(size().width, size().height);
	Graphics imageGr = image.getGraphics();
	imageGr.setColor(getBackground());
	imageGr.fillRect(0, 0, size().width, size().height);
	paintEverything(imageGr);

	getToolkit().sync();

	Graphics ourGr = getGraphics();
	while (true)  {
	    minimallyErase(imageGr);
	    long nextTime = System.currentTimeMillis();
	    animatee_.move(nextTime - currentTime);
	    Thread.yield();
	    currentTime = nextTime;
	    minimallyRepaint(imageGr);
	    ourGr.drawImage(image, 0, 0, this);
	    getToolkit().sync();
	}
    }
    
    private void paintEverything(Graphics g) {
	sortDrawablesByHeight();
	for (int i = 0; i < drawables_.size(); i++)  {
	    Drawable d = (Drawable) drawables_.elementAt(i);
	    d.paint(g);
	}
    }

    // Draw an image for the current time, avoiding as much re-drawing as possible
    private void minimallyRepaint(Graphics g)  {
	sortDrawablesByHeight();
	for (int i = 0; i < drawables_.size(); i++)  {
	    Drawable d = (Drawable) drawables_.elementAt(i);
	    if (d.height() > 0)
		d.paint(g);
	}
    }
   
    // Erase anything that might need erasing. 
    private void minimallyErase(Graphics g)  {
	sortDrawablesByHeight();
	for (int i = 0; i < drawables_.size(); i++)  {
	    Drawable d = (Drawable) drawables_.elementAt(i);
	    if (d.canMove())
		d.erase(g);
	}
    }
    
    // Sort all of the drawables in order of increasing height
    private synchronized void sortDrawablesByHeight() {
	    // I'm lazy, so I'll do a really dumb O(N^2) sort...  Soon,
	    // someone will write a nice quicksort for me :-)
	boolean sorted = false;
	int sz = drawables_.size();
	while (!sorted)  {
	    sorted = true;
	    for(int i = 0; i < sz-1; i++)  {
		Drawable first = (Drawable) drawables_.elementAt(i);
		Drawable second = (Drawable) drawables_.elementAt(i+1);
		if (first.height() > second.height())  {
		    sorted = false;
		    drawables_.setElementAt(second, i);
		    drawables_.setElementAt(first, i+1);
		}
	    }
	}
    }

    private Animatee animatee_;		// The model being animated
    private Vector drawables_;		// Vector<Drawable>, what we draw
}
