/*
	File:  Animatee.java

	Date		Author		Changes
	9/12/96		Bill Foote	Created
*/

package jovial.slotCar.animator;

import java.awt.Dimension;

/**
 * A class representing something being animated.  This class is responsible
 * for providing its Animator with a list of drawables, and for causing the
 * action to "happen".  Animator tells its Animatee that time has passed,
 * which should result in the positions of its drawables moving.  It then
 * asks all of the drawables to draw themselves.
**/

abstract public class Animatee {

    /**
     * Cause the scene being animated to move ahead in time by deltaT
     * milliseconds.  This should *not* cause any re-display...  Animator
     * will ask its drawables to re-draw themselves for that.
     * @param deltaT Amount of time that has passed, in milliseconds
    **/
    abstract public void move(long deltaT);
    
    /**
     * Give the size our view will want to be
     * @return Dimension The size, in pixels
    **/
    abstract public Dimension preferredSize();  
}
