/*
	File:  Race.java

	Date		Author		Changes
	9/11/96		Bill Foote	Created
*/

package jovial.slotCar;

import java.util.*;
import java.awt.*;
import java.applet.Applet;
import jovial.slotCar.animator.Animator;

/**
 *  A main class to start up and run a slot-car rase.
**/


public class RaceApplet extends Applet {

    /**
     * Set up applet
    **/
    public RaceApplet()  {
	GridBagLayout layout = new GridBagLayout();
	setLayout(layout);

	animator_ = new Animator();
	RaceView rv = new RaceView(animator_);
	{

	    GridBagConstraints c = new GridBagConstraints();
	    c.fill = GridBagConstraints.BOTH;
	    c.weightx = 1;
	    c.weighty = 1;
	    layout.setConstraints(animator_, c);
	    add(animator_);
	}

	thread_ = null;
    }
    
    /**
     * Start this applet
    **/
    public void start()  {
	if (thread_ == null) {
	    thread_ = new Thread(animator_);
	    thread_.start();
	}
    }
    
    /**
     * Stop running this applet
    **/
    public void stop() {
	if (thread_ != null && thread_.isAlive())
	    thread_.stop();
	thread_ = null;
    }
    
    private Thread thread_;
    private Animator animator_;

    static public void main(String[] args) {
	Frame f = new Frame();
	RaceApplet ra = new RaceApplet();
	f.add(ra);
	f.pack();
	f.show();
	ra.init();
	ra.start();
    }
}
