/*
	File:  RandomGasPedal.java

	Date		Author		Changes
	09/13/96	Bill Foote	Created

*/

package jovial.slotCar;

import java.util.*;

/**
 *
 *  Represents a gas pedal that varies randomly, in an interesting way.
 *
 *
 * @version 	1.0, September 13 1996
 * @author 	Bill Foote
 */

public class RandomGasPedal implements GasPedal {

    public RandomGasPedal()  {
	throttle_ = 0.75;
	offset_ = 0.50;
	if (gen_ == null)
	    gen_ = new Random();
    }

    public double getThrottle()  {
	double offset;
	if (throttle_ <= 0.60)
	    offset_ = 0.12;
	else if (throttle_ >= 0.90)
	    offset_ = -0.12;
	
	throttle_ += ((gen_.nextDouble() - 0.50) + offset_) / 8.0;
	if (throttle_ < 0.0)
	    throttle_ = 0.0;
	else if (throttle_ > 1.0)
	    throttle_ = 1.0;
	return throttle_;
    }

    private double throttle_;
    private double offset_;
    private static Random gen_;
	// It's important that there be one, shared generator.  If each
	// GasPedal had its own, they'd sometimes seed to the same value,
	// and exactly match!

}
