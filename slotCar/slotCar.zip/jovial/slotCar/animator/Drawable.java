/*
	File:  Drawable.java

	Date		Author		Changes
	09/12/96	Bill Foote	Created

*/

package jovial.slotCar.animator;

import java.util.*;
import java.awt.*;

/**
 *  Represesnts something that can be drawn by an Animator.  When Animator
 *  wants to draw a scene, it sorts its Drawable's by height (to get 
 *  overlapping right), and then asks each Drawable to draw itself.
 *
 *
 * @version 	1.0, September 12 1996
 * @author 	Bill Foote
 */

public abstract class Drawable {

    /**
     * @return the height of this drawable.  Higher drawables will be drawn
     *	       first.  By convention, heights <= 0 means that this Drawable
     *         is part of the "background", and won't be re-drawn with each frame.
    **/
    abstract public int height();

    /**
     * Paint this drawable
     * @param g The grahics to be drawn to
    **/
    abstract public void paint(Graphics g);
    
    /**
     * Erase this drawable.  This only needs to do something if canMove() gives
     * true.
     * @param g The graphics on which erasing is to occur
    **/
    abstract public void erase(Graphics g);
    
    /**
     * @return true iff this drawable might move around the screen
    **/
    abstract public boolean canMove();
}
