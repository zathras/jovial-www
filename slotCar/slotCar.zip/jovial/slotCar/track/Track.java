/*
	File:  Track.java

	Date		Author		Changes
	09/12/96	Bill Foote	Created

*/

package jovial.slotCar.track;

import java.util.*;
import java.awt.Color;
import jovial.slotCar.animator.Animator;

/**
 *  Abstract class for different kinds of track.
 *  <br>
 *  Track is responsible for creating the track segements representing
 *  different track layouts.
 *
 *
 * @version 	1.0, September 12 1996
 * @author 	Bill Foote
 */

abstract public class Track {

    /**
     * Create a Figure 8 track.
     * @param a The animator who will receive our drawables
     * @see FigureEightTrack
    **/
    public static Track createFigureEightTrack(Animator a)  {
	return new FigureEightTrack(a);
    }
    
    /**
     * @return the first segment on this track
    **/
    public abstract TrackSegment firstSegment();
    
    /**
     * @return The color of this track
    **/
    public Color color() {
	return Color.black;
    }
    
}
