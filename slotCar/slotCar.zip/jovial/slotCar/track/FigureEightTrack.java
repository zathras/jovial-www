/*
	File:  FigureEightTrack.java

	Date		Author		Changes
	09/12/96	Bill Foote	Created

*/

package jovial.slotCar.track;

import java.util.*;
import jovial.slotCar.animator.Animator;

/**
 *  A figure-eight track.
 *  See also FigureEightTrack.gif for a description of the meaning
 *  of the variables.
 *  <p>
 *  <img src="FigureEightTrack.gif">
 *  <p>
 *
 *
 * @see Track#createFigureEightTrack in class Track
 * @version 	1.0, September 12 1996
 * @author 	Bill Foote
 */

public class FigureEightTrack extends Track {

    /**
     * Construct a new figure-8 track.
     * @param a The animator who will animate our track segments
    **/

    FigureEightTrack(Animator a)  {
	int xLeft = rm + 2*w + 5;
	int yLeft = xLeft;	// Center of left circle
	double dcc = rm * Math.sqrt(2.0);
	int xRight = (int) (xLeft + 2.0*dcc);
	int yRight = yLeft;	// Center of right circle
	CurvedTrackSegment veryLastSegment
	    = new CurvedTrackSegment(color(),
			xLeft, yLeft, ((7.0 / 4.0) * Math.PI),
			Math.PI * (-3.0 / 4.0), rm, w, null);
	TrackSegment next = veryLastSegment;
	next.setHeight(-2);
	a.addDrawable(next);
	
	int ri = veryLastSegment.ri();
	int ro = veryLastSegment.ro();
	int riDist = (int) ((ri * Math.sqrt(2.0) / 2.0));
	int roDist = (int) ((ro+1) * Math.sqrt(2.0) / 2.0);

	next = new StraightTrackSegment(color(),
			xRight - roDist, yRight - roDist, 2*rm, w,
			((5.0 / 4.0) * Math.PI), next);
	next.setHeight(-2);
	a.addDrawable(next);
	
	next = new CurvedTrackSegment(color(),
			xRight - 2, yRight, ((5.0 / 4.0) * Math.PI),
			(3.0 / 2.0) * Math.PI, rm, w, next);
	next.setFirstSlotIsNearOrigin(false);
	next.setHeight(-2);
	a.addDrawable(next);
	
	    // The overpass we break into three parts so that the part that
	    // actually covers the track can be as short as possible.  This
	    // part is the only one that gets re-drawn.
	
	next = new StraightTrackSegment(color(),
			(int) (xLeft + rm*Math.sqrt(2.0)),
			(int) (yLeft + w/Math.sqrt(2.0)),
			rm-w/2, w,
			((7.0 / 4.0) * Math.PI), next);
	next.setHeight(0);
	a.addDrawable(next);
	
	next = new StraightTrackSegment(color(),
			(int) (xLeft + ri*Math.sqrt(2.0)), yLeft, w+2, w,
			((7.0 / 4.0) * Math.PI), next);
	next.setHeight(2);
	a.addDrawable(next);
	
	next = new StraightTrackSegment(color(),
			xLeft + riDist, yLeft - riDist, rm-w/2+1, w,
			((7.0 / 4.0) * Math.PI), next);
	next.setHeight(0);
	a.addDrawable(next);

	next = new CurvedTrackSegment(color(), xLeft, yLeft, (Math.PI),
				     (-3.0/4.0) * Math.PI, rm, w, next);
	next.setHeight(0);
	a.addDrawable(next);
	firstSegment_ = next;
	
	veryLastSegment.setNext(firstSegment_);
    }
    
    /**
     * @return the first segment on this track
    **/
    public TrackSegment firstSegment() {
	return firstSegment_;
    }
    
    private TrackSegment firstSegment_;		// Beginning of track
    
    private final static int rm = 80;		// See drawing
    private final static int w = 30;		// See drawing
}
