/*
	File:  TrackPosition.java

	Date		Author		Changes
	09/13/96	Bill Foote	Created

*/

package jovial.slotCar.track;

import java.util.*;
import java.awt.Point;


/**
 *
 *  Represents a position on a Track.  Understands how to move along a track,
 *  and can deliver an x,y position, and the orientation of an object moving
 *  along the track.
 *
 *
 * @see Track
 * @see TrackSegment
 * @version 	1.0, September 13 1996
 * @author 	Bill Foote
 */

public class TrackPosition {

    /**
     * Initialize a new position
     * @param slot The slot we're in.  Either 0 or 1.
     * @param start The piece of track we start on
    **/
    public TrackPosition(int slot, TrackSegment start)  {
	slot_ = slot;
	currSegment_ = start;
	distance_ = 0.0;
	moveBy(0.0);    // Initializes position_, etc.
    }
    
    /**
     * Move our position
     * @param dist Distance to move (in pixels)
    **/
    public void moveBy(double distance)  {
	currSegment_.movePositionBy(this, distance);
    }
    
    /**
     * Report the x,y position we represent
     * @return the position
    **/
    public Point position()  {
	return position_;
    }
    
    /**
     * Report the orientation of an object going down the track at the
     * position we represent
     * @return The angle.  0 is 3 o'clock, increasing angles go CCW
    **/
    public double orientation() {
	return orientation_;
    }
    
    /**
     * @return the height associated with our position
    **/
    public int height() {
	return currSegment_.height();
    }
    
    /**
     * @return The slot we represent, 0 or 1
    **/
    public int slot() {
	return slot_;
    }
    
    /**
     * @return the distance along the current segment
    **/
    protected double distance() {
	return distance_;
    }
    
    /**
     * Change our distance along segment.  Should only be called by
     * TrackSegment.
     * @param dist The new distance along our current track segment
    **/
    protected void setDistance(double dist) {
	distance_ = dist;
    }
    
    /**
     * Change the value of orientation.  Should only be called by
     * TrackSegment.
     * @param o The new orientation
    **/
    protected void setOrientation(double o) {
	orientation_ = o;
    }
    
    /**
     * Change our position.  Should only be called by TrackSegment.
     * @param p The new position
    **/
    protected void setPosition(Point p) {
	position_ = p;
    }
    
    
    /**
     * Change the current track segment.  Should only be called by
     * TrackSegment.
     * @param s The new segment
    **/
    protected void setCurrSegment(TrackSegment s)  {
	currSegment_ = s;
    }

    private int slot_;			// Slot we're in, 0 or 1
    private TrackSegment currSegment_;	// Track segment we're on
    private double distance_;		// Distance along that segment
    private double orientation_;	// 0 = 3 o'clock, + --> CCW
    private Point position_;		// x,y position
}
