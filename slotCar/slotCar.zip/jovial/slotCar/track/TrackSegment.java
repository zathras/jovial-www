/*
	File:  TrackSegment.java

	Date		Author		Changes
	09/12/96	Bill Foote	Created

*/

package jovial.slotCar.track;

import java.util.*;
import java.awt.Point;
import java.awt.Graphics;
import java.awt.Color;
import jovial.slotCar.animator.Drawable;


/**
 *  Represents a segment of a race track.
 *
 * @version 	1.0, September 12 1996
 * @author 	Bill Foote
 */

public abstract class TrackSegment extends Drawable {

    /**
     * Initialize a TrackSegment
     * @param next The next segment in this track layout
     * @param c The color of this segment
    **/
    TrackSegment(TrackSegment next, Color c)  {
	next_ = next;
	color_ = c;
	height_ = 0;
	firstSlotIsNearOrigin_ = true;
    }

    /**
     * Give the height of this Drawable
    **/
    public int height()  {
	return height_;
    }
    
    /**
     * Erase this drawable.  This only needs to do something if canMove() gives
     * true.
     * @param g The graphics on which erasing is to occur
    **/
    public void erase(Graphics g) {
	// canMove() is false, so we can ignore this.
    }
        
    /**
     * @return true iff this drawable might move around the screen
    **/
    public boolean canMove() {
	return false;
    }
    
    /**
     * @return The color this track segment will be drawn
    **/
    public Color color() {
	return color_;
    }
    
    /**
     * Set the height of this segment
     * @param h The new height.
    **/
    protected void setHeight(int h)  {
	height_ = h;
    }

    /**
     * Set the next segment pointer.  This is needed so we can make
     * a circular track!
     * @param next The next segment
    **/
    protected void setNext(TrackSegment next)  {
	next_ = next;
    }
    
    /**
     * Get the next segment
     * @return The next segment
    **/
    protected TrackSegment next() {
	return next_;
    }

    /**
     * Move a position along the track, possibly progressing to next
     * segment.  Should only be called from TrackPosition.
     * @param p The position to move
     * @param d The distance to move it (in pixels)
    **/
    abstract protected void movePositionBy(TrackPosition p, double d);
    
    /**
     * @return true iff slot 0 is near the "origin".  Subclasses define
     *  	what this means.
    **/
    protected boolean firstSlotIsNearOrigin() {
	return firstSlotIsNearOrigin_;
    }
    
    /**
     * Set if slot 0 is near the origin.  If unset, defaults to true
     * @param f The new value
    **/
    protected void setFirstSlotIsNearOrigin(boolean f)  {
	firstSlotIsNearOrigin_ = f;
    }

    private int height_;
    private TrackSegment next_;
    private Color color_;
    private boolean firstSlotIsNearOrigin_;

}
