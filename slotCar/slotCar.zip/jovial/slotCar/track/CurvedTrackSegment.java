/*
	File:  CurvedTrackSegment.java

	Date		Author		Changes
	09/12/96	Bill Foote	Created

*/

package jovial.slotCar.track;

import java.util.*;
import java.awt.*;
import java.awt.Point;

/**
 *
 *  Represents a straight piece of track.
 *  <p>
 *  See also FigureEightTrack.gif for a description of the meaning
 *  of the variables.
 *
 *
 * @version 	1.0, September 12 1996
 * @author 	Bill Foote
 */

 class CurvedTrackSegment extends TrackSegment {

    /**
     * Initialize a new curved track segment
     * @param c The color to draw this segment
     * @param x0 x position of center of circle
     * @param y0 y position of center of circle
     * @param theta0 Beginning angle
     * @param deltaTheta Change in angle, may be negative
     * @param rm Middle radius
     * @param w width
     * @param next Next track segment we connect to
    **/
    protected CurvedTrackSegment(Color c, int x0, int y0, double theta0, 
				 double deltaTheta, int rm, int w,
			         TrackSegment next)
    {
	super(next, c);
	theta0_ = theta0;
	deltaTheta_ = deltaTheta;
	x0_ = x0;
	y0_ = y0;
	ri_ = rm - w/2;
	ro_ = ri_ + w-1;

	startAngleDeg_ = (int) (theta0 * 180 / Math.PI);
	arcAngleDeg_ = (int) (deltaTheta * 180 / Math.PI);
    }

    /**
     * Display the track segment
     * @param g Destination for drawing
    **/
    public void paint(Graphics g)  {
	g.setColor(color());

	myDrawArc(g, x0_, y0_, ri_, ro_, startAngleDeg_, arcAngleDeg_);
	g.setColor(Color.white);
	myDrawArc(g, x0_, y0_, ri_-4, ri_-2, startAngleDeg_, arcAngleDeg_);
	myDrawArc(g, x0_, y0_, ro_+1, ro_+3, startAngleDeg_, arcAngleDeg_);
    }
    
    // Like Graphics.drawArc, but takes an inner and outer radius
    private static void myDrawArc(Graphics g, int x, int y, int ri, int ro,
				  int startAngleDeg, int arcAngleDeg)
    {
	    // Unfortunately, the JDK 1.0.2 version of Graphics lacks
	    // a read drawArc.  The following desperate kludge was
	    // stolen from GraphicsUtil.
 	for (int i = ri; i <= ro; i++) {
	    int left = x - i;
	    int top = y - i;
	    int width = i*2;
	    int height = width;
	    g.drawArc(x - i, y - i, i*2, i*2, 
		      startAngleDeg, arcAngleDeg);
	    if (i < ro)  {
		g.drawArc(left,   top,   width-1, height-1, 
			 startAngleDeg, arcAngleDeg);
		g.drawArc(left+1,   top,   width-1, height-1, 
			 startAngleDeg, arcAngleDeg);
		g.drawArc(left,   top+1,   width-1, height-1, 
			 startAngleDeg, arcAngleDeg);
		g.drawArc(left+1,   top+1,   width-1, height-1, 
			 startAngleDeg, arcAngleDeg);
	    }
	}
   }
    
    /**
     * @return the inside radius of our arc
    **/
    public int ri() {
	return ri_;
    }
    
    /**
     * @return the outside radius of our arc
    **/
    public int ro() {
	return ro_;
    }
    
    /**
     * Move a position along the track, possibly progressing to next
     * segment.  Should only be called from TrackPosition.
     * @overrides TrackSegment#movePositionBy
     * @param pos The position to move
     * @param d The distance to move it (in pixels)
    **/
    protected void movePositionBy(TrackPosition pos, double d) {
	double r;  // Radius of our slot
	boolean inside = firstSlotIsNearOrigin() ^ (pos.slot() == 1);
	if (inside) {
	    r = (2.0 * ri_ + ro_) / 3.0;
	} else {
	    r = (ri_ + 2.0 * ro_) / 3.0;
	}
	double l = Math.abs(deltaTheta_ * r);    // slot length
	double newDist = d + pos.distance();
	if (newDist <= l)  {
	    double phi = theta0_ + deltaTheta_ * (newDist / l);
	    pos.setDistance(newDist);
	    if (firstSlotIsNearOrigin())
		pos.setOrientation(phi - Math.PI / 2.0);
	    else
		pos.setOrientation(phi + Math.PI / 2.0);
	    int x = (int) (x0_ + r * Math.cos(phi));
	    int y = (int) (y0_ - r * Math.sin(phi));
	    Point p = new Point(x, y);
	    pos.setPosition(p);
	} else {
	    newDist -= l;
	    pos.setCurrSegment(next());
	    pos.setDistance(0);
	    next().movePositionBy(pos, d);
	}
    }
  
    int x0_;
    int y0_;
    int ri_;	// Inside radius
    int ro_; 	// Outside radius
    int startAngleDeg_;	// Start angle, in degrees
    int arcAngleDeg_;	// arc angle in degrees
    double theta0_;      // Start angle, in radians
    double deltaTheta_; // Arc angle in radians
}
