/*		HtmlGenerator.java
 *
 * Copyright (c) 1997 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. 
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */


package autoclub.connection;

import java.util.*;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.io.PrintWriter;
import java.io.OutputStreamWriter;


/**
 * Base class for all command handlers that generate HTML.
**/

abstract public class HtmlGenerator implements Runnable {

    protected PrintWriter out;

    public InputStream getInputStream() throws IOException {
	final PipedInputStream in = new PipedInputStream();
	final PipedOutputStream outStr = new PipedOutputStream(in);
	out = new PrintWriter(new OutputStreamWriter(outStr));

	// Now run the actual build in a seperate thread...
	Thread t = new Thread(this);
	t.start();

	return in;
    }

    //
    // Overridden by subclasses.  Subclasses must call out.close()
    // when they're done.
    //
    abstract public void run();

}

