/*		FindByIdCommand.java
 *
 * Copyright (c) 1997 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. 
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */

package autoclub.connection;

import java.util.*;
import java.text.DateFormat;
import java.io.IOException;

import autoclub.model.Customer;
import autoclub.model.Accident;


/**
 * Base class for all command handlers that generate HTML.
**/

public class AccidentsCommand extends HtmlGenerator {

    private int customerNumber;

    public AccidentsCommand(String arg) throws IOException {
	try {
	    customerNumber = Integer.parseInt(arg);
	} catch (NumberFormatException ex) {
	    throw new IOException("Expected #, got \"" + arg + "\"");
	}
    }

    public void run() {
	Customer c = DatabaseManager.getCustomer(customerNumber);
	out.println("<html>");
	out.print("<head>Accidents for ");
	if (c == null) {
	    out.print("<bad customer number>");
	} else {
	    out.print(c.name);
	}
	out.println("</head>");

	out.println("<body>");

	if (c == null) {
	    printError();
	} else {
	    printForCustomer(c);
	}
	out.println("</body>");
	out.close();
    }

    private void printError() {
	out.println("I can't find a customer with id " + customerNumber 
		    + ".<br><br>");
	out.println("You might want to try:");
	out.println("<ul>");
	out.println("<li><a href=\"AutoClub://rmi/findbyname.html\">"
		    + "Find Customer by Name</a>");
	out.println("<li><a href=\"AutoClub://rmi/newcustomer.html\">"
		    + "New Customer</a>");
	out.println("</ul>");
    }

    private void printForCustomer(Customer c) {
	out.println("<table>");
	DateFormat fmt = DateFormat.getDateInstance();
	for (int i = 0; i < c.accidents.length; i++) {
	    Accident a = c.accidents[i];
	    out.println("<tr><td>");
	    fmt.setCalendar(a.date);
	    out.println("<a href=\"AutoClub://rmi/accident/" + a.id + "\">"
			+ fmt.format(a.date.getTime()) + "</a>");
	    out.println("</td><td>");
	    if (a.atFault) {
		out.println("<font color=red>At Fault</font>");
	    } else {
		out.println("Not At Fault");
	    }
	    out.println("</td></tr>");
	}
	out.println("</table>");
    }
}

