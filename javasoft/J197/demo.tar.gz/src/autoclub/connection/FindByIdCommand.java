/*		FindByIdCommand.java
 *
 * Copyright (c) 1997 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. 
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */

package autoclub.connection;

import java.util.*;
import java.io.IOException;

import autoclub.model.Customer;
import autoclub.model.Accident;


/**
 * Base class for all command handlers that generate HTML.
**/

public class FindByIdCommand extends HtmlGenerator {

    private int customerNumber;

    public FindByIdCommand(String arg) throws IOException {
	try {
	    customerNumber = Integer.parseInt(arg.substring(3, arg.length()));
	} catch (NumberFormatException ex) {
	    throw new IOException("Expected id=#, got \"" + arg + "\"");
	}
    }

    public void run() {
	out.println("<html>");
	out.println("<head>Customer ID number " + customerNumber + "</head>");
	out.println("<body>");

	Customer c = DatabaseManager.getCustomer(customerNumber);
	if (c == null) {
	    printError();
	} else {
	    printCustomer(c);
	}
	out.println("</body>");
	out.close();
    }

    private void printError() {
	out.println("I can't find a customer with id " + customerNumber 
		    + ".<br><br>");
	out.println("You might want to try:");
	out.println("<ul>");
	out.println("<li><a href=\"AutoClub://rmi/findbyname.html\">"
		    + "Find Customer by Name</a>");
	out.println("<li><a href=\"AutoClub://rmi/newcustomer.html\">"
		    + "New Customer</a>");
	out.println("</ul>");
    }

    private void printCustomer(Customer c) {
	out.println("<table>");
	out.println("<tr><td>Name:  </td><td>" + c.name + "</td></tr>");
	out.println("<tr><td>Address:&nbsp;&nbsp;&nbsp;&nbsp;</td><td>" + c.address + "</td></tr>");
	out.println("<tr><td>City:  </td><td>" + c.city + "</td></tr>");
	out.println("<tr><td>State:  </td><td>" + c.state + "</td></tr>");
	out.println("<tr><td>Zip:  </td><td>" + c.zip + "</td></tr>");
	out.println("</table>");
	out.println("<br>");
	out.println("<a href=\"AutoClub://rmi/accidents/" + c.id + "\">"
		     + c.accidents.length + " accidents in the past year.</a>");
    }
}

