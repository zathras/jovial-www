/*		DatabaseManager.java
 *
 * Copyright (c) 1997 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. 
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */


package autoclub.connection;

import java.util.*;
import java.rmi.*;
import java.net.MalformedURLException;
import autoclub.rmi.CustomerFinder;
import autoclub.model.Customer;

/**
 * This class manages fetching objects from the remote server.
 * <p>
 * We use a very primitive caching pollicy here:  If we see something
 * once, we cache it forever.  A real application would need to do
 * better.
**/


public class DatabaseManager {

    public static Hashtable customerCache = new Hashtable();
    public static CustomerFinder finder = null;

    /**
     * @return the customer with the given id, or null if there is none.
    **/
    public static synchronized Customer getCustomer(int id) {
	Integer idI = new Integer(id);
        Object o = customerCache.get(idI);
	if (o != null) {
	    return (Customer) o;
	}
	try {
	    o = getFinder().findCustomer(id);
	} catch (Exception e) {
	    System.out.println("RMI exception: " + e);
	    e.printStackTrace();
	    return null;
	}
	if (o != null) {
	    customerCache.put(idI, o);
	}
	return (Customer) o;
    }

    private static CustomerFinder getFinder() 
		throws RemoteException, MalformedURLException, 
		       NotBoundException {
	if (finder == null) {
	    finder = (CustomerFinder) Naming.lookup("/CustomerFinder");
	}
	return finder;
    }
}
