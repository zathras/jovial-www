/*			Handler.java
 *
 * Copyright (c) 1997 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. 
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */

package autoclub.protocol.autoclub;

import java.net.URLStreamHandler;
import java.net.URL;
import java.net.URLConnection;
import java.net.MalformedURLException;
import java.io.IOException;

import autoclub.connection.RmiURLConnection;


/**
 * A URLStreamHandler that implements autoclub:.  This handler looks at the
 * URL to determine what kind of connection to create.  If the host is
 * "static", then the URL is really static content, which we get from
 * our application server.  If the host is "rmi", then it's some kind of
 * query from something fetched from the object server.
**/

public class Handler extends URLStreamHandler {

    private static URL appserver;

    /**
     * Get the appserver URL.  Throw MalformedURLException if there's a problem.
    **/
    private static URL getAppserver() throws MalformedURLException {
	if (appserver != null) {
	    return appserver;
	}
	String name = System.getProperty("AutoClub.appserver");
	if (name == null) {
	    throw new MalformedURLException(
		"The property AutoClub.appserver is not defined");
	}
	appserver = new URL(name);
	return appserver;
    }


    public Handler() {
    }

    public synchronized URLConnection openConnection(URL u) throws IOException {
	String host = u.getHost();

	// Static content: Make a URL from the file part relative to appserver
	if ("static".equals(host)) {
	    URL realURL;
	    try {
		String fileName = u.getFile();
		if (fileName.startsWith("/")) {
		    fileName = fileName.substring(1, fileName.length());
		}
		realURL = new URL(getAppserver(), fileName);
	    } catch (MalformedURLException ex) {
		throw new IOException(ex.toString());
	    }
	    return realURL.openConnection();
	}
	
	// RMI:  Open the connection.  It's up to RmiURLConnection to make 
	// sense of the URL.
	if ("rmi".equals(host)) {
	    return new RmiURLConnection(u);
	}

	// No match?  Must be an invalid URL.
	throw new IOException("Invalid autoclub URL:  " + u);
    }

}
