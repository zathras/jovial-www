/*			RmiURLConnection.java
 *
 * Copyright (c) 1997 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. 
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */
package autoclub.connection;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.*;


public class RmiURLConnection extends URLConnection {

    /**
     * Arguments sent to us for a form "post".  null if there are none.
    **/
    private ByteArrayOutputStream postArgument = null;

    public RmiURLConnection(URL u) {
	super(u);
    }

    public void connect() throws IOException {
    }

    public String getHeaderFieldKey(int n)  {
        switch (n)  {
            case 0:     return "content-type";
            case 1:     return "expires";
            default:    return null;
        }
    }
 
    public String getHeaderField(int n)  {
        switch (n)  {
            case 0:     return "text/html";     // Content-type:
		// Force everything to be re-read -- it's a query,
		// so the underlying data might have changed.
            case 1:     return Long.toString(System.currentTimeMillis() / 1000);
            default:    return null;
        }
    }
 
    public String getHeaderField(String name)  {
        for (int i = 0; ; i++)  {
            String n = getHeaderFieldKey(i);
            if (n == null)
                return null;
            if (n.equals(name))
                return getHeaderField(i);
        }
    }

    /**
     * Get the output stream.  Used for form POSTs.
    **/
    public OutputStream getOutputStream() throws IOException {
        postArgument = new ByteArrayOutputStream();
	return postArgument;
    }
 
    public InputStream getInputStream() throws IOException {
	String cmd = getURL().getFile();
	String arg = "";
	if (postArgument != null) {
	    arg = postArgument.toString();
	}
	if ("/findbyid".equals(cmd)) {
	    return (new FindByIdCommand(arg)).getInputStream();
	} else if (cmd.startsWith("/accidents/")) {
	    return (new AccidentsCommand(cmd.substring(11, cmd.length())))
			.getInputStream();
	} else {
	    throw new IOException("Invalid command: " + cmd);
	}
    }

}

