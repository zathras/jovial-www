/*		CustomerFinderImpl.java
 *
 * Copyright (c) 1997 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. 
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */

package autoclub.rmi;

import java.util.*;
import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;

import autoclub.model.Customer;
import autoclub.model.Accident;

/**
 * An implementation of the server side of CustomerFinder
**/

public class CustomerFinderImpl
    extends UnicastRemoteObject 
    implements CustomerFinder
{
    private static Hashtable customers;		// Our database

    static {
	customers = new Hashtable();
	Customer c = new Customer();
	c.id = 1;
	c.name = "A. C. Dent";
	c.address = "123 Blind Corner Boulevard";
	c.city = "Verglas City";
	c.state = "WA";
	c.zip = "55555";

	c.accidents = new Accident[3];
	c.accidents[0] = new Accident(1997, 1, 12, true);
	c.accidents[1] = new Accident(1997, 2, 17, false);
	c.accidents[2] = new Accident(1997, 3, 3, true);

	customers.put(new Integer(c.id), c);
    }

    public CustomerFinderImpl() throws RemoteException {
	super();
    }


    /**
     * @return the customer with the given id, or null if not found
    **/
    public Customer findCustomer(int id) throws RemoteException {
        Object o = customers.get(new Integer(id));
	System.out.println("Request for customer " + id + " being served...");
        return (Customer) o;	// perhaps null
    }


    /**
     * Initialize ourselves as an RMI server with the name "CustomerFinder"
    **/
    public static void main(String args[]) {
	System.setSecurityManager(new RMISecurityManager());
	try {
	    CustomerFinderImpl obj = new CustomerFinderImpl();
	    Naming.rebind("/CustomerFinder", obj);
	    System.out.println("CustomerFinder bound in registry");
	} catch (Exception e) {
	    System.out.println("CustomerFinderImpl error: " + e);
	    e.printStackTrace();
	}
    }
}
