/*
 * @(#)QueryListener.java	1.14 98/03/06
 *
 * Copyright (c) 1997 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. Please refer to the file "copyright.html"
 * for further important copyright and licensing information.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */

package hat.server;

/**
 *
 * @version     1.14, 03/06/98
 * @author      Bill Foote
 */


import java.net.Socket;
import java.net.ServerSocket;
import java.net.InetAddress;

import java.io.InputStream;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.Writer;
import java.io.BufferedWriter;
import java.io.PrintWriter;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.BufferedOutputStream;

import hat.model.Snapshot;

public class QueryListener implements Runnable {


    private Snapshot snapshot;
    private int port;

    public QueryListener(int port) {
	this.port = port;
	this.snapshot = null;	// Client will setModel when it's ready
    }

    public void setModel(Snapshot ss) {
	this.snapshot = ss;
    }

    public void run() {
	try {
	    waitForRequests();
	} catch (IOException ex) {
	    ex.printStackTrace();
	    System.exit(1);
	}
    }

    private void waitForRequests() throws IOException {
	ServerSocket ss = new ServerSocket(port);
	Thread last = null;
	for (;;) {
	    Socket s = ss.accept();
	    Thread t = new Thread(new HttpReader(s, snapshot));
	    if (snapshot == null) {
		t.setPriority(Thread.NORM_PRIORITY+1);
	    } else {
		t.setPriority(Thread.NORM_PRIORITY-1);
		if (last != null) {
		    try {
			last.setPriority(Thread.NORM_PRIORITY-2);
		    } catch (Throwable ignored) {
		    }
		    // If the thread is no longer alive, we'll get a 
		    // NullPointerException
		}
	    }
	    t.start();
	    last = t;
	}
    }

}
