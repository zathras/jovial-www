/*
 * @(#)RootStackQuery.java	1.3 98/03/06
 *
 * Copyright (c) 1997 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. Please refer to the file "copyright.html"
 * for further important copyright and licensing information.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */

package hat.server;


import hat.model.*;

/**
 * Query to show the StackTrace for a given root
 *
 * @version     1.3, 03/06/98
 * @author      Bill Foote
 */


class RootStackQuery extends QueryHandler {

    public RootStackQuery() {
    }

    public void run() {
	int index = parseHex(query);
	Root root = snapshot.getRootAt(index);
	if (root == null) {
	    error("Root at " + index + " not found");
	    return;
	}
	StackTrace st = root.getStackTrace();
	if (st == null) {
	    error("No stack trace for " + root.getDescription());
	    return;
	}
	startHtml("Stack Trace for " + root.getDescription());
	out.println("<p>");
	printStackTrace(st);
	out.println("</p>");
	endHtml();
    }

}
