/*
 * @(#)AllClassesQuery.java	1.7 98/03/06
 *
 * Copyright (c) 1997 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. Please refer to the file "copyright.html"
 * for further important copyright and licensing information.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */

package hat.server;

import hat.model.*;
import hat.util.ArraySorter;
import hat.util.Comparer;

/**
 *
 * @version     1.7, 03/06/98
 * @author      Bill Foote
 */


class AllClassesQuery extends QueryHandler {


    public AllClassesQuery() {
    }

    public void run() {
	startHtml("All Classes");

	JavaClass[] classes = snapshot.getClasses();
	ArraySorter.sort(classes, new Comparer() {
	    public int compare(Object lhs, Object rhs) {
		String left = ((JavaClass) lhs).getName();
		String right = ((JavaClass) rhs).getName();
		if (left.startsWith("[") != right.startsWith("[")) {
		    // Arrays at the end
		    if (left.startsWith("[")) {
			return 1;
		    } else {
			return -1;
		    }
		}
		boolean lc = left.indexOf(".") != -1;
		boolean rc = right.indexOf(".") != -1;
		if (lc != rc) {
		    // The default package comes first
		    if (!lc) {
			return -1;
		    } else {
			return 1;
		    }
		}
		return left.compareTo(right);
	    }
	});

	String lastPackage = null;
	for (int i = 0; i < classes.length; i++) {
	    String name = classes[i].getName();
	    int pos = name.lastIndexOf(".");
	    String pkg;
	    if (name.startsWith("[")) {
		pkg = "<Arrays>";
	    } else if (pos == -1) {
		pkg = "<Default Package>";
	    } else {
		pkg = name.substring(0, pos);
	    }
	    if (!pkg.equals(lastPackage)) {
		out.print("<h2>Package ");
		print(pkg);
		out.println("</h2>");
	    }
	    lastPackage = pkg;
	    printClass(classes[i]);
	    out.println("<br>");
	}

	out.println("<h2>Other Queries</h2>");
	out.println("<ul>");
	out.println("<li>");
	printAnchorStart();
	out.print("showRoots/\">");
	print("Show all members of the rootset");
	out.println("</a>");
	out.println("<li>");
	printAnchorStart();
	out.print("showInstanceCounts/\">");
	print("Show instance counts for all classes");
	out.println("</a>");
	out.println("</ul>");

	endHtml();
    }

    
}
