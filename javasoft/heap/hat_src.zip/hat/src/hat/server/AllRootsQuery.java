/*
 * @(#)AllRootsQuery.java	1.4 98/03/06
 *
 * Copyright (c) 1997 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. Please refer to the file "copyright.html"
 * for further important copyright and licensing information.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */

package hat.server;

import java.util.Vector;

import hat.model.*;
import hat.util.ArraySorter;
import hat.util.Comparer;

/**
 *
 * @version     1.4, 03/06/98
 * @author      Bill Foote
 */


class AllRootsQuery extends QueryHandler {

    public AllRootsQuery() {
    }

    public void run() {
	startHtml("All Members of the Rootset");

	Root[] roots = snapshot.getRoots();
	ArraySorter.sort(roots, new Comparer() {
	    public int compare(Object lhs, Object rhs) {
		Root left = (Root) lhs;
		Root right = (Root) rhs;
		int d = left.getType() - right.getType();
		if (d != 0) {
		    return -d;	// More interesting values are *higher*
		}
		return left.getDescription().compareTo(right.getDescription());
	    }
	});

	int lastType = Root.INVALID_TYPE;

	for (int i= 0; i < roots.length; i++) {
	    Root root = roots[i];

	    if (root.getType() != lastType) {
		lastType = root.getType();
		out.print("<h2>");
		print(root.getTypeName() + " References");
		out.println("</h2>");
	    }

	    printRoot(root);
	    if (root.getReferer() != null) {
		out.print("<small> (from ");
		printThingAnchorTag(root.getReferer().getId());
		print(root.getReferer().toString());
		out.print(")</a></small>");
	    }
	    out.print(" :<br>");

	    JavaThing t = snapshot.findThing(root.getId());
	    if (t != null) {	// It should always be
		print("--> ");
		printThing(t);
		out.println("<br>");
	    }
	}

	out.println("<h2>Other Queries</h2>");
	out.println("<ul>");
	out.println("<li>");
	printAnchorStart();
	out.print("\">");
	print("Show All Classes");
	out.println("</a>");
	out.println("</ul>");

	endHtml();
    }
}
