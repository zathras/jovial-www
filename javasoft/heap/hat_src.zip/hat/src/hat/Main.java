/*
 * @(#)Main.java	1.12 99/06/03
 *
 * Copyright (c) 1997 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. Please refer to the file "copyright.html"
 * for further important copyright and licensing information.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */

package hat;

import java.io.IOException;
import java.io.File;

import hat.model.Snapshot;
import hat.model.ReachableExcludes;
import hat.server.QueryListener;

/**
 *
 * @version     1.12, 06/03/99
 * @author      Bill Foote
 */


public class Main {

    private static String VERSION_STRING = "HAT version 1.0.5";

    private static void usage() {
	System.err.println("Usage:  hat [-stack=<bool>] [-refs=<bool>] [-port=<port>] [-baseline=<file> -debug=<int>] [-version] <file>");
	System.err.println("\t-stack=false:  Turn off tracking the call stack for object allocation");
	System.err.println("\t-refs=false:  Turn off tracking of references to objects");
	System.err.println("\t-port=<port>:  Set the port for the HTTP server.  Defaults to 7000");
	System.err.println("\t-exclude=<file>:  Specify a file that lists data members that should");
	System.err.println("\t\tbe excluded from the reachableFrom query.");
	System.err.println("\t-baseline=<file>:  Specify a baseline object dump.  Objects in");
	System.err.println("\t\tboth heap dumps with the same ID and same class will");
	System.err.println("\t\tbe marked as not being \"new\".");
	System.err.println("\t-debug=<int>:  Set debug level.");
	System.err.println("\t\t0:  No debug output");
	System.err.println("\t\t1:  Debug hprof file parsing");
	System.err.println("\t-version  Report version number");
	System.err.println("<file>  The file to read");
	System.err.println();
	System.err.println("For a JDK 1.2 (or better) dump file, you may specify which dump in the file");
	System.err.println("by appending \":<number>\" to the file name, i.e. \"foo.hprof:3\".");
	System.err.println();
	System.err.println("All boolean options default to \"true\"");
	System.exit(1);
    }

    //
    // Convert s to a boolean.  If it's invalid, abort the program.
    //
    private static boolean booleanValue(String s) {
	if ("true".equalsIgnoreCase(s)) {
	    return true;
	} else if ("false".equalsIgnoreCase(s)) {
	    return false;
	} else {
	    usage();
	    return false;	// Never happens
	}
    }

    public static void main(String[] args) {
	if (args.length < 1) {
	    usage();
	}
	int portNumber = 7000;
	boolean callStack = true;
	boolean calculateRefs = true;
	String baselineDump = null;
	String excludeFileName = null;
	int debugLevel = 0;
	for (int i = 0; ; i++) {
	    if ("-version".equals(args[i])) {
		System.out.println(VERSION_STRING);
		System.exit(0);
	    }
	    if (i >= (args.length - 1)) {
		break;
	    }
	    int pos = args[i].indexOf('=');
	    if (pos < 0) {
		usage();
	    }
	    String key = args[i].substring(0, pos);
	    String value = args[i].substring(pos+1, args[i].length());
	    if ("-stack".equals(key)) {
		callStack = booleanValue(value);
	    } else if ("-refs".equals(key)) {
		calculateRefs = booleanValue(value);
	    } else if ("-port".equals(key)) {
		portNumber = Integer.parseInt(value, 10);
	    } else if ("-exclude".equals(key)) {
		excludeFileName = value;
	    } else if ("-baseline".equals(key)) {
		baselineDump = value;
	    } else if ("-debug".equals(key)) {
		debugLevel = Integer.parseInt(value, 10);
	    }
	}
	String fileName = args[args.length - 1];
	Snapshot model = null;
	QueryListener listener = new QueryListener(portNumber);
	Thread t = new Thread(listener, "Query Listener");
	t.setPriority(Thread.NORM_PRIORITY+1);
	t.start();
	System.out.println("Started HTTP server on port " + portNumber);

	File excludeFile = null;
	if (excludeFileName != null) {
	    excludeFile = new File(excludeFileName);
	    if (!excludeFile.exists()) {
		System.out.println("Exclude file " + excludeFile 
				    + " does not exist.  Aborting.");
		System.exit(1);
	    }
	}

	System.out.println("Reading from " + fileName + "...");
	try {
	    model = hat.parser.Reader.readFile(fileName, callStack, debugLevel);
	} catch (IOException ex) {
	    ex.printStackTrace();
	    System.exit(1);
	} catch (RuntimeException ex) {
	    ex.printStackTrace();
	    System.exit(1);
	}
	System.out.println("Snapshot read, resolving...");
	model.resolve(calculateRefs);
	System.out.println("Snapshot resolved.");

	if (excludeFile != null) {
	    model.setReachableExcludes(new ReachableExcludes(excludeFile));
	}

	if (baselineDump != null) {
	    System.out.println("Reading baseline snapshot...");
	    Snapshot baseline = null;
	    try {
		baseline = hat.parser.Reader.readFile(baselineDump, false, 
						      debugLevel);
	    } catch (IOException ex) {
		ex.printStackTrace();
		System.exit(1);
	    } catch (RuntimeException ex) {
		ex.printStackTrace();
		System.exit(1);
	    }
	    baseline.resolve(false);
	    System.out.println("Discovering new objects...");
	    model.markNewRelativeTo(baseline);
	    baseline = null;	// Guard against conservative GC
	}

	listener.setModel(model);
	System.out.println("Server is ready.");
    }
}
