/*
 * @(#)JavaField.java	1.3 98/03/06
 *
 * Copyright (c) 1997 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. Please refer to the file "copyright.html"
 * for further important copyright and licensing information.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */

package hat.model;


/**
 *
 * @version     1.3, 03/06/98
 * @author      Bill Foote
 */

public class JavaField {
    
    private String name;
    private String signature;

    public JavaField(String name, String signature) {
	this.name = name;
	this.signature = signature;
    }


    /**
     * @return true if the type of this field is something that has an ID.
     *		int fields, for exampe, don't.
     */
    public boolean hasId() {
	char ch = signature.charAt(0);
	return (ch == '[' || ch == 'L');
    }

    public String getName() {
	return name;
    }

    public String getSignature() {
	return signature;
    }

}
