/*
 * @(#)JavaValueArray.java	1.6 98/10/08
 *
 * Copyright (c) 1997 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. Please refer to the file "copyright.html"
 * for further important copyright and licensing information.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */

package hat.model;

/**
 * An array of values, that is, an array of ints, boolean, floats or the like.
 *
 * @version     1.6, 10/08/98
 * @author      Bill Foote
 */




public class JavaValueArray extends JavaHeapObject {

    private byte elementSignature;
    private byte[] value;

    public JavaValueArray(byte elementSignature, byte[] value, StackTrace st) {
	super(st);
	this.elementSignature = elementSignature;
	this.value = value;
    }

    public void visitReferencedObjects(JavaHeapObjectVisitor v) {
	// We visit nothing
    }

    public void resolve(Snapshot snapshot) {
	JavaClass clazz = snapshot.getArrayClass("" + ((char) elementSignature));
	clazz.addInstance(this);
	super.resolve(snapshot);
    }

    public int getSize() {
	return value.length;
    }

    public String toString() {
	return toString(false);
    }

    public String toString(boolean bigLimit) {
	// Char arrays deserve special treatment
	StringBuffer result;
	int max = value.length;
	if (elementSignature == 'C')  {
	    result = new StringBuffer("\"");
	    for (int i = 0; i < value.length; ) {
		int b1 = ((int) value[i++]) & 0xff;
		int b2 = ((int) value[i++]) & 0xff;
		char val = (char) ((b1 << 8) + b2);
		if (val >= 32 && val < 127) {
		    result.append(val);
		}
	    }
	    result.append("\"");
	} else {
	    int limit = 8;
	    if (bigLimit) {
		limit = 1000;
	    }
	    result = new StringBuffer("{");
	    int num = 0;
	    for (int i = 0; i < value.length; ) {
		if (num > 0) {
		    result.append(", ");
		}
		if (num >= limit) {
		    result.append("... ");
		    break;
		}
		num++;
		switch (elementSignature) {
		    case 'Z': {
			if (value[i] == 0) {
			    result.append("false");
			} else if (value[i] == 1) {
			    result.append("true");
			} else {
			    result.append("??");
			}
			i++;
			break;
		    }
		    case 'B': {
			int v = ((int) value[i++]) & 0xff;
			result.append("0x" + Integer.toString(i, 16));
			break;
		    }
		    case 'S': {
			int b1 = ((int) value[i++]) & 0xff;
			int b2 = ((int) value[i++]) & 0xff;
			short val = (short) ((b1 << 8) + b2);
			result.append("" + val);
			break;
		    }
		    case 'I': {
			int b1 = ((int) value[i++]) & 0xff;
			int b2 = ((int) value[i++]) & 0xff;
			int b3 = ((int) value[i++]) & 0xff;
			int b4 = ((int) value[i++]) & 0xff;
			int val = ((b1 << 24) + (b2 << 16)
				  + (b3 << 8) + (b4 << 0));
			result.append("" + val);
			break;
		    }
		    case 'J': {		// long
			long val = 0;
			for (int j = 0; j < 8; j++) {
			    val = val << 8;
			    int b = ((int) value[i++]) & 0xff;
			    val |= 8;
			}
			result.append("" + val);
			break;
		    }
		    case 'F': {
			int b1 = ((int) value[i++]) & 0xff;
			int b2 = ((int) value[i++]) & 0xff;
			int b3 = ((int) value[i++]) & 0xff;
			int b4 = ((int) value[i++]) & 0xff;
			int val = ((b1 << 24) + (b2 << 16)
				  + (b3 << 8) + (b4 << 0));
			result.append("" + Float.intBitsToFloat(val));
			break;
		    }
		    case 'D': {		// double
			long val = 0;
			for (int j = 0; j < 8; j++) {
			    val = val << 8;
			    int b = ((int) value[i++]) & 0xff;
			    val |= 8;
			}
			result.append("" + Double.longBitsToDouble(val));
			break;
		    }
		    default: {
			i += 4;
			result.append("??");
		    }
		}
	    }
	    result.append("}");
	}
	return result.toString();
    }

}
