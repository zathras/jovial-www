/*
 * @(#)JavaObjectArray.java	1.11 98/10/08
 *
 * Copyright (c) 1997 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. Please refer to the file "copyright.html"
 * for further important copyright and licensing information.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */

package hat.model;

/**
 *
 * @version     1.11, 10/08/98
 * @author      Bill Foote
 */


public class JavaObjectArray extends JavaHeapObject {

    private JavaThing[] values;
    private int size;	// Size of object in bytes
    private JavaClass clazz = null;	// The class of this object

    private int[] rawData;	// null after resolve() done
    private int elementClassID;

    /**
     * Construct a new JavaObjectArray.
     */
    public JavaObjectArray(int[] rawData, int size, StackTrace st) {
	this(rawData, size, st, 0);
    }

    public JavaObjectArray(int[] rawData, int size, StackTrace st,
			   int elementClassID) {
	super(st);
	this.rawData = rawData;
	this.size = size;
	this.elementClassID = elementClassID;
    }

    public JavaClass getClazz() {
	return clazz;
    }

    public void resolve(Snapshot snapshot) {
	values = new JavaThing[rawData.length];
	for (int i = 0; i < rawData.length; i++) {
	    values[i] = snapshot.findThing(rawData[i]);
	}
	rawData = null;
	if (elementClassID != 0) {
	    JavaThing t = snapshot.findThing(elementClassID);
	    if (t != null && t instanceof JavaClass) {
		JavaClass el = (JavaClass) t;
		String nm = el.getName();
		if (!nm.startsWith("[")) {
		    nm = "L" + el.getName() + ";";
		}
		clazz = snapshot.getArrayClass(nm);
	    }
	}
	if (clazz == null) {
	    snapshot.getOtherArrayType().addInstance(this);
	} else {
	    clazz.addInstance(this);
	}
	super.resolve(snapshot);
    }

    public JavaThing[] getValues() {
	return values;
    }

    public String toString() {
	if (clazz == null) {
	    return "array";
	} else {
	    return "Instance of " + clazz.getName();
	}
    }

    public int compareTo(JavaThing other) {
	if (other instanceof JavaObjectArray) {
	    return 0;
	}
	return super.compareTo(other);
    }

    public int getSize() {
	return size;
    }

    public void visitReferencedObjects(JavaHeapObjectVisitor v) {
	for (int i = 0; i < values.length; i++) {
	    if (values[i] != null && values[i] instanceof JavaHeapObject) {
		v.visit((JavaHeapObject) values[i]);
	    }
	}
    }

    /**
     * Describe the reference that this thing has to target.  This will only
     * be called if target is in the array returned by getChildrenForRootset.
     */
    public String describeReferenceTo(JavaThing target, Snapshot ss) {
	for (int i = 0; i < values.length; i++) {
	    if (values[i] == target) {
		return "Element " + i + " of " + this;
	    }
	}
	return super.describeReferenceTo(target, ss);
    }

}
