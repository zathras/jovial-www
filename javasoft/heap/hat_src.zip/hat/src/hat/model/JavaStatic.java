/*
 * @(#)JavaStatic.java	1.7 98/10/08
 *
 * Copyright (c) 1997 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. Please refer to the file "copyright.html"
 * for further important copyright and licensing information.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */

package hat.model;

/**
 *
 * @version     1.7, 10/08/98
 * @author      Bill Foote
 */

/**
 * Represents the value of a static field of a JavaClass
 */

public class JavaStatic {

    private JavaField field;
    private JavaThing value;

    public JavaStatic(JavaField field, JavaThing value) {
	this.field = field;
	this.value = value;
    }

    public void resolve(JavaClass clazz, Snapshot snapshot) {
	value = value.dereference(snapshot, field);
	if (value.isHeapAllocated()) {
	    JavaHeapObject ho = (JavaHeapObject) value;
	    String s = "Static reference from " + clazz.getName()
		       + "." + field.getName();
	    snapshot.addRoot(new Root(ho.getId(), clazz.getId(), 
				      Root.JAVA_STATIC, s));
	}
    }

    public JavaField getField() {
	return field;
    }

    public JavaThing getValue() {
	return value;
    }
}
