/*
 * @(#)JavaValue.java	1.8 98/10/08
 *
 * Copyright (c) 1997 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. Please refer to the file "copyright.html"
 * for further important copyright and licensing information.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */

package hat.model;

/**
 * Abstract base class for all value types (ints, longs, floats, etc.)
 *
 * @version     1.8, 10/08/98
 * @author      Bill Foote
 */




public abstract class JavaValue extends JavaThing {

    protected JavaValue() {
    }

    public boolean isHeapAllocated() {
	return false;
    }

    abstract public String toString();

    public int getSize() {
	// The size of a value is already accounted for in the class
	// that has the data member.
	return 0;
    }

}
